<?php
	echo "data stored successfully";
?>